package com.zona._15.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.model.EstadoPedido;
import com.zona._15.model.Factura;
import com.zona._15.model.Pedido;
import com.zona._15.repository.FacturaRepository;
import com.zona._15.repository.PedidoRepository;

/** Arma los datos del panel de control (inicio del administrador). */
@Service
public class PanelService {

    private static final String[] DIAS = {"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"};

    private static final Map<EstadoPedido, String> COLORES = new EnumMap<>(EstadoPedido.class);

    static {
        COLORES.put(EstadoPedido.RECIBIDO, "#ff7a45");
        COLORES.put(EstadoPedido.EN_PREPARACION, "#ffb020");
        COLORES.put(EstadoPedido.LISTO, "#3fb950");
        COLORES.put(EstadoPedido.ENTREGADO, "#7c6ee6");
        COLORES.put(EstadoPedido.CANCELADO, "#8b949e");
    }

    private final ProductoService productos;
    private final ClienteService clientes;
    private final PedidoRepository pedidos;
    private final FacturaRepository facturas;

    public PanelService(ProductoService productos, ClienteService clientes,
                        PedidoRepository pedidos, FacturaRepository facturas) {
        this.productos = productos;
        this.clientes = clientes;
        this.pedidos = pedidos;
        this.facturas = facturas;
    }

    @Transactional(readOnly = true)
    public PanelResumen generar() {
        LocalDate hoy = LocalDate.now();

        long pedidosHoy = pedidos.countByFechaGreaterThanEqualAndFechaLessThan(
                hoy.atStartOfDay(), hoy.plusDays(1).atStartOfDay());
        int ventasHoy = facturas.findByFechaGreaterThanEqualAndFechaLessThanOrderByFechaAsc(
                        hoy.atStartOfDay(), hoy.plusDays(1).atStartOfDay())
                .stream().mapToInt(Factura::getTotal).sum();

        return new PanelResumen(
                productos.contar(), clientes.contar(), pedidosHoy, ventasHoy,
                ultimosSieteDias(hoy), resumenPorEstado(), gradiente(),
                filas(pedidos.findTop5ByOrderByFechaDesc()),
                filas(pedidos.findByEstadoInOrderByFechaAsc(
                        List.of(EstadoPedido.RECIBIDO, EstadoPedido.EN_PREPARACION, EstadoPedido.LISTO))));
    }

    // Pedidos de cada uno de los últimos 7 días (el último es hoy).
    private List<PanelResumen.DiaSemana> ultimosSieteDias(LocalDate hoy) {
        long[] cantidades = new long[7];
        String[] etiquetas = new String[7];
        long maximo = 0;
        for (int i = 0; i < 7; i++) {
            LocalDate dia = hoy.minusDays(6 - i);
            cantidades[i] = pedidos.countByFechaGreaterThanEqualAndFechaLessThan(
                    dia.atStartOfDay(), dia.plusDays(1).atStartOfDay());
            etiquetas[i] = DIAS[dia.getDayOfWeek().getValue() - 1];
            maximo = Math.max(maximo, cantidades[i]);
        }
        List<PanelResumen.DiaSemana> lista = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            int porcentaje = (maximo == 0) ? 0 : (int) Math.round(cantidades[i] * 100.0 / maximo);
            if (cantidades[i] > 0 && porcentaje < 6) {
                porcentaje = 6;
            }
            lista.add(new PanelResumen.DiaSemana(etiquetas[i], cantidades[i], porcentaje));
        }
        return lista;
    }

    private List<PanelResumen.EstadoResumen> resumenPorEstado() {
        long total = 0;
        Map<EstadoPedido, Long> conteo = new EnumMap<>(EstadoPedido.class);
        for (EstadoPedido estado : EstadoPedido.values()) {
            long cantidad = pedidos.countByEstado(estado);
            conteo.put(estado, cantidad);
            total += cantidad;
        }
        List<PanelResumen.EstadoResumen> lista = new ArrayList<>();
        for (EstadoPedido estado : EstadoPedido.values()) {
            long cantidad = conteo.get(estado);
            int porcentaje = (total == 0) ? 0 : (int) Math.round(cantidad * 100.0 / total);
            lista.add(new PanelResumen.EstadoResumen(
                    estado.getEtiqueta(), cantidad, porcentaje, COLORES.get(estado)));
        }
        return lista;
    }

    // Fondo del gráfico circular: un tramo de color por cada estado que tenga pedidos.
    private String gradiente() {
        long total = 0;
        for (EstadoPedido estado : EstadoPedido.values()) {
            total += pedidos.countByEstado(estado);
        }
        if (total == 0) {
            return "conic-gradient(#8b949e 0% 100%)";
        }
        StringBuilder css = new StringBuilder("conic-gradient(");
        double acumulado = 0;
        boolean primero = true;
        for (EstadoPedido estado : EstadoPedido.values()) {
            long cantidad = pedidos.countByEstado(estado);
            if (cantidad == 0) {
                continue;
            }
            double fin = acumulado + cantidad * 100.0 / total;
            if (!primero) {
                css.append(", ");
            }
            css.append(COLORES.get(estado)).append(' ')
                    .append(String.format(Locale.ROOT, "%.2f", acumulado)).append("% ")
                    .append(String.format(Locale.ROOT, "%.2f", fin)).append('%');
            acumulado = fin;
            primero = false;
        }
        return css.append(')').toString();
    }

    private List<PanelResumen.FilaPedido> filas(List<Pedido> lista) {
        DateTimeFormatter hora = DateTimeFormatter.ofPattern("HH:mm");
        List<PanelResumen.FilaPedido> filas = new ArrayList<>();
        for (Pedido p : lista) {
            filas.add(new PanelResumen.FilaPedido(
                    p.getId(),
                    p.getCliente() != null ? p.getCliente().getNombre() : "Sin cliente",
                    p.getEstado().getEtiqueta(),
                    p.getEstado().name(),
                    p.getTotal(),
                    p.getFecha().format(hora)));
        }
        return filas;
    }
}