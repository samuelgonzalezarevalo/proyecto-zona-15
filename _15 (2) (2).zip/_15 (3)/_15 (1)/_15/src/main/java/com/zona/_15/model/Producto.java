package com.zona._15.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "productos")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre es obligatorio.")
    @Size(min = 3, max = 80, message = "El nombre debe tener entre 3 y 80 caracteres.")
    @Column(nullable = false, length = 80)
    private String nombre;

    @NotBlank(message = "La categoría es obligatoria.")
    @Size(max = 40, message = "La categoría puede tener máximo 40 caracteres.")
    @Column(nullable = false, length = 40)
    private String categoria;

    @NotNull(message = "El precio es obligatorio.")
    @Min(value = 1, message = "El precio debe ser mayor que cero.")
    @Column(nullable = false)
    private Integer precio;

    public Producto() {
    }

    public Producto(String nombre, Integer precio, String categoria) {
        setNombre(nombre);
        setPrecio(precio);
        setCategoria(categoria);
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        this.nombre = (nombre == null) ? null : nombre.trim().toUpperCase();
    }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) {
        this.categoria = (categoria == null) ? null : categoria.trim().toUpperCase();
    }

    public Integer getPrecio() { return precio; }
    public void setPrecio(Integer precio) { this.precio = precio; }
}