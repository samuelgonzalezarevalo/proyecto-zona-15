package com.zona._15.model;

public enum TipoPedido {
    LOCAL("Para el local"),
    DOMICILIO("A domicilio");

    private final String etiqueta;

    TipoPedido(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }
}