package com.zona._15.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Proveedor;

public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {

    List<Proveedor> findAllByOrderByNombreAsc();
}