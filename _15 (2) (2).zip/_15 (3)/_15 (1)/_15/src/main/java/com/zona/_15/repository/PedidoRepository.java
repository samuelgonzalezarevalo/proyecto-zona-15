package com.zona._15.repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zona._15.model.EstadoPedido;
import com.zona._15.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    // Trae el pedido junto con su cliente, sus líneas y los productos de cada línea.
    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    Optional<Pedido> findConDetallesById(Long id);

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findAllByOrderByFechaDesc();

    // Pedidos en ciertos estados, del más antiguo al más reciente (orden de llegada).
    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findByEstadoInOrderByFechaAsc(Collection<EstadoPedido> estados);

    // Pedidos de un cliente, del más reciente al más antiguo.
    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findByClienteIdOrderByFechaDesc(Long clienteId);

    long countByClienteId(Long clienteId);

    // Mesas: pedidos cuyo cliente está sentado ahora mismo.
    List<Pedido> findByMesaEnUsoTrue();

    List<Pedido> findByMesaIdAndMesaEnUsoTrue(Long mesaId);

    boolean existsByMesaIdAndMesaEnUsoTrue(Long mesaId);

    // Al borrar una mesa, los pedidos viejos que la usaron quedan sin mesa.
    @Modifying
    @Query("update Pedido p set p.mesa = null where p.mesa.id = :mesaId")
    void quitarMesa(@Param("mesaId") Long mesaId);

    // Panel de control: conteos y últimos pedidos.
    long countByEstado(EstadoPedido estado);

    long countByFechaGreaterThanEqualAndFechaLessThan(LocalDateTime desde, LocalDateTime hasta);

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findTop5ByOrderByFechaDesc();
}