package com.zona._15.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zona._15.model.Usuario;
import com.zona._15.service.UsuarioService;

/** Solo administrador: lista de cuentas y cuántos pedidos ha hecho cada una. */
@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService servicio;

    public UsuarioController(UsuarioService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public String listar(Model modelo) {
        List<Usuario> lista = servicio.listar();
        modelo.addAttribute("usuarios", lista);
        modelo.addAttribute("conteo", servicio.pedidosPorUsuario(lista));
        return "usuarios";
    }
}