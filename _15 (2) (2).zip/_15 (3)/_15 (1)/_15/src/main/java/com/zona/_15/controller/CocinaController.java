package com.zona._15.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.zona._15.service.MesaService;
import com.zona._15.service.PedidoService;

/** RF005: pantalla de cocina con los pedidos pendientes por orden de llegada y las mesas del local. */
@Controller
public class CocinaController {

    private final PedidoService servicio;
    private final MesaService servicioMesas;

    public CocinaController(PedidoService servicio, MesaService servicioMesas) {
        this.servicio = servicio;
        this.servicioMesas = servicioMesas;
    }

    @GetMapping("/cocina")
    public String cocina(Model modelo) {
        modelo.addAttribute("pedidos", servicio.listarParaCocina());
        modelo.addAttribute("mesas", servicioMesas.listarConEstado());
        return "cocina";
    }
}