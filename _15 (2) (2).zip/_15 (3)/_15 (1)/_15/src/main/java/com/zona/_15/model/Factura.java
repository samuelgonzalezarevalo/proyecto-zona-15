package com.zona._15.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

/**
 * Factura o comprobante de una venta (RF004).
 * Viene de la clase Factura de FastService: pedido, fecha y total.
 * Se agregan el método de pago, el desglose del impuesto, la identificación del cliente y el CUFE.
 */
@Entity
@Table(name = "facturas")
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Un pedido solo puede tener una factura.
    @OneToOne(optional = false)
    @JoinColumn(name = "pedido_id", nullable = false, unique = true)
    private Pedido pedido;

    @Column(nullable = false)
    private LocalDateTime fecha = LocalDateTime.now();

    // Total a pagar (el precio del menú ya incluye el impuesto, si aplica).
    @Column(nullable = false)
    private int total;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MetodoPago metodoPago;

    // Los siguientes campos pueden ser null en facturas hechas antes de esta versión.
    private Integer subtotal;

    private Integer impuesto;

    private Integer impuestoPorcentaje;

    // Cédula o NIT del cliente, solo si lo pidió en la factura.
    @Column(length = 20)
    private String identificacionCliente;

    // Código de la factura (de práctica, no lo valida la DIAN).
    @Column(length = 96)
    private String cufe;

    public Factura() {
    }

    public Factura(Pedido pedido, int subtotal, int impuesto, int impuestoPorcentaje, int total,
                   MetodoPago metodoPago, String identificacionCliente) {
        this.pedido = pedido;
        this.subtotal = subtotal;
        this.impuesto = impuesto;
        this.impuestoPorcentaje = impuestoPorcentaje;
        this.total = total;
        this.metodoPago = metodoPago;
        this.identificacionCliente = identificacionCliente;
    }

    public String getNumero() {
        return String.format("F-%05d", id);
    }

    public String getFechaTexto() {
        return fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    public int getSubtotal() { return subtotal != null ? subtotal : total; }

    public int getImpuesto() { return impuesto != null ? impuesto : 0; }

    public int getImpuestoPorcentaje() { return impuestoPorcentaje != null ? impuestoPorcentaje : 0; }

    public Long getId() { return id; }

    public Pedido getPedido() { return pedido; }

    public LocalDateTime getFecha() { return fecha; }

    public int getTotal() { return total; }

    public MetodoPago getMetodoPago() { return metodoPago; }

    public String getIdentificacionCliente() { return identificacionCliente; }

    public String getCufe() { return cufe; }
    public void setCufe(String cufe) { this.cufe = cufe; }
}