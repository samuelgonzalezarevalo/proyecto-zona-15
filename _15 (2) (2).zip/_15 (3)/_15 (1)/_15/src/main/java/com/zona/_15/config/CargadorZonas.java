package com.zona._15.config;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.zona._15.model.Zona;
import com.zona._15.repository.ZonaRepository;

/**
 * Deja dos barrios de Turbaco la primera vez. El resto los agrega el administrador
 * desde la sección Zonas, según donde realmente lleguen los domicilios.
 */
@Component
public class CargadorZonas implements CommandLineRunner {

    private final ZonaRepository zonas;

    public CargadorZonas(ZonaRepository zonas) {
        this.zonas = zonas;
    }

    @Override
    public void run(String... args) {
        if (zonas.count() > 0) {
            return;
        }
        zonas.saveAll(List.of(new Zona("Los Laureles"), new Zona("Plan Parejo")));
    }
}