package com.zona._15.controller;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.zona._15.service.ReporteService;

/** RF008: reportes de ventas del día, de un rango de fechas y por producto. */
@Controller
public class ReporteController {

    private final ReporteService servicio;

    public ReporteController(ReporteService servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/reportes")
    public String reportes(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            Model modelo) {
        // Si no se elige fecha, se muestra el día de hoy.
        LocalDate hoy = LocalDate.now();
        if (desde == null) {
            desde = hoy;
        }
        if (hasta == null) {
            hasta = hoy;
        }
        if (hasta.isBefore(desde)) {
            LocalDate cambio = desde;
            desde = hasta;
            hasta = cambio;
        }
        modelo.addAttribute("reporte", servicio.generar(desde, hasta));
        // Como texto (aaaa-mm-dd), que es lo que entienden los campos de fecha.
        modelo.addAttribute("desde", desde.toString());
        modelo.addAttribute("hasta", hasta.toString());
        return "reportes";
    }
}