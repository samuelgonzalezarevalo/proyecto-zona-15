package com.zona._15.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Mesa;

public interface MesaRepository extends JpaRepository<Mesa, Long> {

    List<Mesa> findAllByOrderByNumeroAsc();

    boolean existsByNumero(Integer numero);
}