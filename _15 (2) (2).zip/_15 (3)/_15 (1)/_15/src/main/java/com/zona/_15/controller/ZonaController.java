package com.zona._15.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Zona;
import com.zona._15.service.ZonaService;

import jakarta.validation.Valid;

/** Solo administrador: barrios de Turbaco donde se hacen domicilios. */
@Controller
@RequestMapping("/zonas")
public class ZonaController {

    private final ZonaService servicio;

    public ZonaController(ZonaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public String listar(Model modelo) {
        modelo.addAttribute("zona", new Zona());
        modelo.addAttribute("zonas", servicio.listar());
        return "zonas";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("zona") Zona zona, BindingResult resultado,
                          Model modelo, RedirectAttributes aviso) {
        if (!resultado.hasFieldErrors("nombre") && servicio.nombreEnUso(zona.getNombre())) {
            resultado.rejectValue("nombre", "repetido", "Ese barrio ya está en la lista.");
        }
        if (resultado.hasErrors()) {
            modelo.addAttribute("zonas", servicio.listar());
            return "zonas";
        }
        servicio.guardar(zona);
        aviso.addFlashAttribute("mensaje", "Zona agregada.");
        return "redirect:/zonas";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes aviso) {
        servicio.eliminar(id);
        aviso.addFlashAttribute("mensaje", "Zona eliminada.");
        return "redirect:/zonas";
    }
}