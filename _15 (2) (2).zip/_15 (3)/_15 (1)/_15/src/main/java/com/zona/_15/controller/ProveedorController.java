package com.zona._15.controller;

import java.util.Optional;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Proveedor;
import com.zona._15.service.ProveedorService;

import jakarta.validation.Valid;

/** RF009: proveedores a los que se les compran insumos. */
@Controller
@RequestMapping("/proveedores")
public class ProveedorController {

    private final ProveedorService servicio;

    public ProveedorController(ProveedorService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public String listar(Model modelo) {
        modelo.addAttribute("proveedores", servicio.listar());
        return "proveedores/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model modelo) {
        modelo.addAttribute("proveedor", new Proveedor());
        return "proveedores/form";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model modelo, RedirectAttributes aviso) {
        Optional<Proveedor> proveedor = servicio.buscar(id);
        if (proveedor.isEmpty()) {
            aviso.addFlashAttribute("error", "El proveedor no existe.");
            return "redirect:/proveedores";
        }
        modelo.addAttribute("proveedor", proveedor.get());
        return "proveedores/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("proveedor") Proveedor proveedor,
                          BindingResult resultado, RedirectAttributes aviso) {
        if (resultado.hasErrors()) {
            return "proveedores/form";
        }
        servicio.guardar(proveedor);
        aviso.addFlashAttribute("mensaje", "Proveedor guardado correctamente.");
        return "redirect:/proveedores";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes aviso) {
        try {
            servicio.eliminar(id);
            aviso.addFlashAttribute("mensaje", "Proveedor eliminado.");
        } catch (DataIntegrityViolationException e) {
            aviso.addFlashAttribute("error", "No se puede eliminar: el proveedor tiene compras registradas.");
        }
        return "redirect:/proveedores";
    }
}