package com.zona._15.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.model.DetallePedido;
import com.zona._15.model.Factura;
import com.zona._15.model.MetodoPago;
import com.zona._15.repository.FacturaRepository;

/** RF008: reportes de ventas. Solo cuentan los pedidos cobrados (con factura). */
@Service
public class ReporteService {

    private final FacturaRepository facturas;

    public ReporteService(FacturaRepository facturas) {
        this.facturas = facturas;
    }

    @Transactional(readOnly = true)
    public ReporteVentas generar(LocalDate desde, LocalDate hasta) {
        List<Factura> lista = facturas.findByFechaGreaterThanEqualAndFechaLessThanOrderByFechaAsc(
                desde.atStartOfDay(), hasta.plusDays(1).atStartOfDay());

        int totalVentas = lista.stream().mapToInt(Factura::getTotal).sum();

        // Ventas por método de pago (siempre salen los tres, aunque estén en cero).
        Map<MetodoPago, ReporteVentas.PorMetodo> metodos = new EnumMap<>(MetodoPago.class);
        for (MetodoPago m : MetodoPago.values()) {
            metodos.put(m, new ReporteVentas.PorMetodo(m.getEtiqueta()));
        }
        for (Factura f : lista) {
            metodos.get(f.getMetodoPago()).sumar(f.getTotal());
        }

        // Ventas por producto: se juntan las líneas de todos los pedidos cobrados.
        Map<Long, ReporteVentas.PorProducto> productos = new LinkedHashMap<>();
        for (Factura f : lista) {
            for (DetallePedido d : f.getPedido().getDetalles()) {
                ReporteVentas.PorProducto linea = productos.computeIfAbsent(
                        d.getProducto().getId(),
                        id -> new ReporteVentas.PorProducto(
                                d.getProducto().getNombre(), d.getProducto().getCategoria()));
                linea.sumar(d.getCantidad(), d.getSubtotal());
            }
        }
        List<ReporteVentas.PorProducto> porProducto = new ArrayList<>(productos.values());
        // Primero los más vendidos.
        porProducto.sort(Comparator.comparingInt(ReporteVentas.PorProducto::getCantidad).reversed());

        return new ReporteVentas(desde, hasta, lista.size(), totalVentas,
                new ArrayList<>(metodos.values()), porProducto);
    }
}