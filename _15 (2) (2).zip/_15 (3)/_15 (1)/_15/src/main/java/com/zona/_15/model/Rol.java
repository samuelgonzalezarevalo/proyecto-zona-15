package com.zona._15.model;

public enum Rol {
    ADMIN("Administrador"),
    USUARIO("Cliente");

    private final String etiqueta;

    Rol(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }
}