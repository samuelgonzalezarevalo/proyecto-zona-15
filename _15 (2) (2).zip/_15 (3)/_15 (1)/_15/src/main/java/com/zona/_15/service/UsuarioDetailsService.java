package com.zona._15.service;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.zona._15.model.Usuario;
import com.zona._15.repository.UsuarioRepository;

/** Le dice a Spring Security cómo buscar a un usuario cuando alguien inicia sesión. */
@Service
public class UsuarioDetailsService implements UserDetailsService {

    private final UsuarioRepository usuarios;

    public UsuarioDetailsService(UsuarioRepository usuarios) {
        this.usuarios = usuarios;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = usuarios.findByUsername(username.trim().toLowerCase())
                .orElseThrow(() -> new UsernameNotFoundException("No existe el usuario."));
        return User.withUsername(usuario.getUsername())
                .password(usuario.getClave())
                .roles(usuario.getRol().name())
                .build();
    }
}