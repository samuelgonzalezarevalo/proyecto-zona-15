package com.zona._15.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.zona._15.model.Proveedor;
import com.zona._15.repository.ProveedorRepository;

@Service
public class ProveedorService {

    private final ProveedorRepository repositorio;

    public ProveedorService(ProveedorRepository repositorio) {
        this.repositorio = repositorio;
    }

    public List<Proveedor> listar() {
        return repositorio.findAllByOrderByNombreAsc();
    }

    public Optional<Proveedor> buscar(Long id) {
        return repositorio.findById(id);
    }

    public Proveedor guardar(Proveedor proveedor) {
        return repositorio.save(proveedor);
    }

    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }
}