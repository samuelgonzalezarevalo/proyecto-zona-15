package com.zona._15.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Zona;

public interface ZonaRepository extends JpaRepository<Zona, Long> {

    List<Zona> findAllByOrderByNombreAsc();

    boolean existsByNombreIgnoreCase(String nombre);
}