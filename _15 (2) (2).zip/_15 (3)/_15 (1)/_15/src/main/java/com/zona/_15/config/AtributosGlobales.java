package com.zona._15.config;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import jakarta.servlet.http.HttpServletRequest;

/** Datos que todas las páginas necesitan para armar el menú según quién inició sesión. */
@ControllerAdvice
public class AtributosGlobales {

    @ModelAttribute("esAdmin")
    public boolean esAdmin() {
        return tieneRol("ROLE_ADMIN");
    }

    @ModelAttribute("esUsuario")
    public boolean esUsuario() {
        return tieneRol("ROLE_USUARIO");
    }

    @ModelAttribute("nombreSesion")
    public String nombreSesion() {
        Authentication autenticacion = SecurityContextHolder.getContext().getAuthentication();
        if (autenticacion == null || autenticacion instanceof AnonymousAuthenticationToken) {
            return null;
        }
        return autenticacion.getName();
    }

    // Dirección de la página actual, para resaltar la opción activa del menú.
    @ModelAttribute("rutaActual")
    public String rutaActual(HttpServletRequest solicitud) {
        return solicitud.getRequestURI();
    }

    private boolean tieneRol(String rol) {
        Authentication autenticacion = SecurityContextHolder.getContext().getAuthentication();
        return autenticacion != null && autenticacion.getAuthorities().stream()
                .anyMatch(permiso -> permiso.getAuthority().equals(rol));
    }
}