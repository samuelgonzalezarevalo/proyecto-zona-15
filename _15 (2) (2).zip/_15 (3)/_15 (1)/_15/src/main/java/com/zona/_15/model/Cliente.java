package com.zona._15.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "clientes")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre es obligatorio.")
    @Size(min = 3, max = 50, message = "El nombre debe tener entre 3 y 50 caracteres.")
    @Pattern(regexp = "^[A-Za-zÁÉÍÓÚÜáéíóúüÑñ ]+$", message = "El nombre solo puede contener letras y espacios.")
    @Column(nullable = false, length = 50)
    private String nombre;

    @NotBlank(message = "El teléfono es obligatorio.")
    @Pattern(regexp = "^\\d{10}$", message = "El teléfono debe tener exactamente 10 dígitos.")
    @Column(nullable = false, length = 10, unique = true)
    private String telefono;

    @Size(max = 120, message = "La dirección puede tener máximo 120 caracteres.")
    @Column(length = 120)
    private String direccion;

    public Cliente() {
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        this.nombre = (nombre == null) ? null : nombre.trim().toUpperCase();
    }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) {
        this.telefono = (telefono == null) ? null : telefono.trim();
    }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) {
        this.direccion = (direccion == null || direccion.isBlank()) ? null : direccion.trim();
    }

    @Override
    public String toString() {
        return nombre + " (" + telefono + ")";
    }
}