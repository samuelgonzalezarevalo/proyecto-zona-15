package com.zona._15.controller;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.zona._15.model.RegistroForm;
import com.zona._15.service.UsuarioService;

import jakarta.validation.Valid;

/** Páginas de inicio de sesión y de creación de cuenta. */
@Controller
public class AutenticacionController {

    private final UsuarioService servicio;

    public AutenticacionController(UsuarioService servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/registro")
    public String registro(Model modelo) {
        modelo.addAttribute("registro", new RegistroForm());
        return "registro";
    }

    @PostMapping("/registro")
    public String registrar(@Valid @ModelAttribute("registro") RegistroForm registro,
                            BindingResult resultado) {
        if (!resultado.hasFieldErrors("clave") && !resultado.hasFieldErrors("confirmar")
                && !registro.getClave().equals(registro.getConfirmar())) {
            resultado.rejectValue("confirmar", "distinta", "Las contraseñas no coinciden.");
        }
        if (!resultado.hasFieldErrors("username") && servicio.usernameEnUso(registro.getUsername())) {
            resultado.rejectValue("username", "repetido", "Ese usuario ya existe. Elige otro.");
        }
        if (!resultado.hasFieldErrors("telefono") && servicio.telefonoEnUso(registro.getTelefono())) {
            resultado.rejectValue("telefono", "repetido",
                    "Ya hay un cliente con ese teléfono. Pide ayuda en el restaurante.");
        }
        if (resultado.hasErrors()) {
            return "registro";
        }
        try {
            servicio.registrar(registro);
        } catch (DataIntegrityViolationException e) {
            resultado.reject("error", "No se pudo crear la cuenta. Intenta de nuevo.");
            return "registro";
        }
        return "redirect:/login?registrado";
    }
}