package com.zona._15.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Producto;
import com.zona._15.service.ProductoService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService servicio;

    public ProductoController(ProductoService servicio) {
        this.servicio = servicio;
    }

    @ModelAttribute("categorias")
    public List<String> categorias() {
        return servicio.categorias();
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Model modelo) {
        modelo.addAttribute("productos", servicio.listar(q));
        modelo.addAttribute("q", q);
        return "productos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model modelo) {
        modelo.addAttribute("producto", new Producto());
        return "productos/form";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model modelo, RedirectAttributes aviso) {
        Optional<Producto> producto = servicio.buscar(id);
        if (producto.isEmpty()) {
            aviso.addFlashAttribute("error", "El producto no existe.");
            return "redirect:/productos";
        }
        modelo.addAttribute("producto", producto.get());
        return "productos/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("producto") Producto producto,
                          BindingResult resultado, RedirectAttributes aviso) {
        if (resultado.hasErrors()) {
            return "productos/form";
        }
        servicio.guardar(producto);
        aviso.addFlashAttribute("mensaje", "Producto guardado correctamente.");
        return "redirect:/productos";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes aviso) {
        try {
            servicio.eliminar(id);
            aviso.addFlashAttribute("mensaje", "Producto eliminado.");
        } catch (DataIntegrityViolationException e) {
            aviso.addFlashAttribute("error", "No se puede eliminar: el producto ya se usó en pedidos.");
        }
        return "redirect:/productos";
    }
}
