package com.zona._15.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.zona._15.model.Producto;
import com.zona._15.repository.ProductoRepository;

@Service
public class ProductoService {

    private final ProductoRepository repositorio;

    public ProductoService(ProductoRepository repositorio) {
        this.repositorio = repositorio;
    }

    public List<Producto> listar(String busqueda) {
        Sort orden = Sort.by("categoria").ascending().and(Sort.by("nombre").ascending());
        if (busqueda == null || busqueda.isBlank()) {
            return repositorio.findAll(orden);
        }
        String texto = busqueda.trim();
        return repositorio.findByNombreContainingIgnoreCaseOrCategoriaContainingIgnoreCase(texto, texto, orden);
    }

    public Optional<Producto> buscar(Long id) {
        return repositorio.findById(id);
    }

    public Producto guardar(Producto producto) {
        return repositorio.save(producto);
    }

    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }

    public List<String> categorias() {
        return repositorio.listarCategorias();
    }

    public long contar() {
        return repositorio.count();
    }
}