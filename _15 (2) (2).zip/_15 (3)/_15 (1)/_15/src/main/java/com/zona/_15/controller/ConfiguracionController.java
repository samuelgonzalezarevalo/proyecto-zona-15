package com.zona._15.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Configuración del sistema: por ahora, el cambio entre tema claro y tema oscuro. */
@Controller
public class ConfiguracionController {

    @GetMapping("/configuracion")
    public String configuracion() {
        return "configuracion";
    }
}