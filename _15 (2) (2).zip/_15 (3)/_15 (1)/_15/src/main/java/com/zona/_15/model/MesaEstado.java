package com.zona._15.model;

/** Una mesa junto con su estado actual: libre, o en uso por un pedido. */
public class MesaEstado {

    private final Mesa mesa;
    private final Long pedidoId;

    public MesaEstado(Mesa mesa, Long pedidoId) {
        this.mesa = mesa;
        this.pedidoId = pedidoId;
    }

    public boolean isOcupada() {
        return pedidoId != null;
    }

    public Mesa getMesa() { return mesa; }

    // Número del pedido que está usando la mesa (null si está libre).
    public Long getPedidoId() { return pedidoId; }
}