package com.zona._15.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Cliente;
import com.zona._15.model.LineaCarrito;
import com.zona._15.model.Pedido;
import com.zona._15.model.Producto;
import com.zona._15.model.TipoPedido;
import com.zona._15.model.Usuario;
import com.zona._15.service.MisPedidosService;
import com.zona._15.service.PedidoService;
import com.zona._15.service.ProductoService;
import com.zona._15.service.UsuarioService;
import com.zona._15.service.ZonaService;

import jakarta.servlet.http.HttpSession;

/** Área del cliente: ver el menú, armar su pedido y ver sus propios pedidos. */
@Controller
public class TiendaController {

    private static final int MAXIMO = 99;

    private final ProductoService productos;
    private final PedidoService pedidos;
    private final MisPedidosService misPedidos;
    private final UsuarioService usuarios;
    private final ZonaService zonas;

    public TiendaController(ProductoService productos, PedidoService pedidos,
                            MisPedidosService misPedidos, UsuarioService usuarios,
                            ZonaService zonas) {
        this.productos = productos;
        this.pedidos = pedidos;
        this.misPedidos = misPedidos;
        this.usuarios = usuarios;
        this.zonas = zonas;
    }

    // El pedido que se está armando se guarda en la sesión: id del producto -> cantidad.
    @SuppressWarnings("unchecked")
    private Map<Long, Integer> carrito(HttpSession sesion) {
        Object guardado = sesion.getAttribute("carrito");
        if (guardado == null) {
            Map<Long, Integer> nuevo = new LinkedHashMap<>();
            sesion.setAttribute("carrito", nuevo);
            return nuevo;
        }
        return (Map<Long, Integer>) guardado;
    }

    private Cliente clienteActual(Principal usuario) {
        return usuarios.buscarPorUsername(usuario.getName()).map(Usuario::getCliente).orElse(null);
    }

    @GetMapping("/menu")
    public String menu(@RequestParam(required = false) String q, HttpSession sesion, Model modelo) {
        modelo.addAttribute("productos", productos.listar(q));
        modelo.addAttribute("q", q);
        modelo.addAttribute("enCarrito", carrito(sesion).values().stream().mapToInt(Integer::intValue).sum());
        return "menu";
    }

    @PostMapping("/carrito/agregar")
    public String agregar(@RequestParam Long productoId, @RequestParam(defaultValue = "1") int cantidad,
                          HttpSession sesion, RedirectAttributes aviso) {
        if (cantidad < 1 || cantidad > MAXIMO) {
            aviso.addFlashAttribute("error", "La cantidad debe estar entre 1 y 99.");
            return "redirect:/menu";
        }
        Optional<Producto> producto = productos.buscar(productoId);
        if (producto.isEmpty()) {
            aviso.addFlashAttribute("error", "Ese producto ya no existe.");
            return "redirect:/menu";
        }
        carrito(sesion).merge(productoId, cantidad, (actual, nueva) -> Math.min(MAXIMO, actual + nueva));
        aviso.addFlashAttribute("mensaje", producto.get().getNombre() + " agregado a tu pedido.");
        return "redirect:/menu";
    }

    @GetMapping("/carrito")
    public String verCarrito(HttpSession sesion, Model modelo) {
        List<LineaCarrito> lineas = new ArrayList<>();
        int total = 0;
        for (Map.Entry<Long, Integer> item : carrito(sesion).entrySet()) {
            Optional<Producto> producto = productos.buscar(item.getKey());
            if (producto.isPresent()) {
                LineaCarrito linea = new LineaCarrito(producto.get(), item.getValue());
                lineas.add(linea);
                total += linea.getSubtotal();
            }
        }
        modelo.addAttribute("lineas", lineas);
        modelo.addAttribute("total", total);
        modelo.addAttribute("tipos", TipoPedido.values());
        modelo.addAttribute("zonas", zonas.listar());
        return "carrito";
    }

    @PostMapping("/carrito/quitar")
    public String quitar(@RequestParam Long productoId, HttpSession sesion) {
        carrito(sesion).remove(productoId);
        return "redirect:/carrito";
    }

    @PostMapping("/carrito/confirmar")
    public String confirmar(@RequestParam TipoPedido tipo, @RequestParam(required = false) Long zonaId,
                            HttpSession sesion, Principal usuario, RedirectAttributes aviso) {
        Map<Long, Integer> carrito = carrito(sesion);
        Cliente cliente = clienteActual(usuario);
        if (carrito.isEmpty()) {
            aviso.addFlashAttribute("error", "Tu pedido está vacío. Agrega productos del menú.");
            return "redirect:/carrito";
        }
        if (cliente == null) {
            aviso.addFlashAttribute("error", "Tu cuenta no tiene un cliente asociado.");
            return "redirect:/carrito";
        }
        if (tipo == TipoPedido.DOMICILIO && cliente.getDireccion() == null) {
            aviso.addFlashAttribute("error", "Tu cuenta no tiene dirección. Elige \"Para el local\".");
            return "redirect:/carrito";
        }
        try {
            Pedido pedido = misPedidos.crear(cliente.getId(), tipo, carrito, zonaId);
            carrito.clear();
            aviso.addFlashAttribute("mensaje", "¡Pedido enviado! El restaurante ya lo recibió.");
            return "redirect:/mis-pedidos/" + pedido.getId();
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
            return "redirect:/carrito";
        }
    }

    @GetMapping("/mis-pedidos")
    public String listarMisPedidos(Principal usuario, Model modelo) {
        Cliente cliente = clienteActual(usuario);
        List<Pedido> lista = (cliente == null) ? List.of() : misPedidos.listar(cliente.getId());
        modelo.addAttribute("pedidos", lista);
        return "mis-pedidos";
    }

    @GetMapping("/mis-pedidos/{id}")
    public String verMiPedido(@PathVariable Long id, Principal usuario, Model modelo,
                              RedirectAttributes aviso) {
        Cliente cliente = clienteActual(usuario);
        Optional<Pedido> pedido = (cliente == null)
                ? Optional.empty() : misPedidos.buscarDelCliente(id, cliente.getId());
        if (pedido.isEmpty()) {
            aviso.addFlashAttribute("error", "No encontramos ese pedido.");
            return "redirect:/mis-pedidos";
        }
        modelo.addAttribute("pedido", pedido.get());
        return "mi-pedido";
    }

    @PostMapping("/mis-pedidos/{id}/cancelar")
    public String cancelar(@PathVariable Long id, Principal usuario, RedirectAttributes aviso) {
        Cliente cliente = clienteActual(usuario);
        boolean esSuyo = cliente != null && misPedidos.buscarDelCliente(id, cliente.getId()).isPresent();
        if (!esSuyo) {
            aviso.addFlashAttribute("error", "No encontramos ese pedido.");
            return "redirect:/mis-pedidos";
        }
        try {
            pedidos.cancelar(id);
            aviso.addFlashAttribute("mensaje", "Pedido cancelado.");
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/mis-pedidos/" + id;
    }
}
