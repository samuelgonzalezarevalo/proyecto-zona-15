package com.zona._15.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/** Mesa del local, con su número y la cantidad de sillas. */
@Entity
@Table(name = "mesas")
public class Mesa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "El número de la mesa es obligatorio.")
    @Min(value = 1, message = "El número debe ser mayor que cero.")
    @Max(value = 99, message = "El número puede ser máximo 99.")
    @Column(nullable = false, unique = true)
    private Integer numero;

    @NotNull(message = "La cantidad de sillas es obligatoria.")
    @Min(value = 1, message = "Debe tener al menos 1 silla.")
    @Max(value = 20, message = "Puede tener máximo 20 sillas.")
    @Column(nullable = false)
    private Integer sillas;

    public Mesa() {
    }

    public String getNombre() {
        return "Mesa " + numero;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Integer getNumero() { return numero; }
    public void setNumero(Integer numero) { this.numero = numero; }

    public Integer getSillas() { return sillas; }
    public void setSillas(Integer sillas) { this.sillas = sillas; }
}