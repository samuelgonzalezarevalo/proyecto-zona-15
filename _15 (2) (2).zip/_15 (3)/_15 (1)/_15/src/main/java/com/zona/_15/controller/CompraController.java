package com.zona._15.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Compra;
import com.zona._15.model.Proveedor;
import com.zona._15.service.CompraService;
import com.zona._15.service.ProveedorService;

import jakarta.validation.Valid;

/** RF009: registrar las compras de insumos con proveedor, cantidad y costo. */
@Controller
@RequestMapping("/compras")
public class CompraController {

    private final CompraService servicio;
    private final ProveedorService servicioProveedores;

    public CompraController(CompraService servicio, ProveedorService servicioProveedores) {
        this.servicio = servicio;
        this.servicioProveedores = servicioProveedores;
    }

    // Disponibles en las páginas de este controlador (para las listas desplegables).
    @ModelAttribute("proveedores")
    public List<Proveedor> proveedores() {
        return servicioProveedores.listar();
    }

    @ModelAttribute("unidades")
    public List<String> unidades() {
        return List.of("unidades", "kg", "libras", "litros", "paquetes", "bultos");
    }

    @GetMapping
    public String listar(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            Model modelo) {
        // Si no se elige fecha, se muestra lo que va del mes.
        LocalDate hoy = LocalDate.now();
        if (desde == null) {
            desde = hoy.withDayOfMonth(1);
        }
        if (hasta == null) {
            hasta = hoy;
        }
        if (hasta.isBefore(desde)) {
            LocalDate cambio = desde;
            desde = hasta;
            hasta = cambio;
        }
        List<Compra> lista = servicio.listar(desde, hasta);
        modelo.addAttribute("compras", lista);
        modelo.addAttribute("total", lista.stream().mapToInt(Compra::getCostoTotal).sum());
        modelo.addAttribute("desde", desde.toString());
        modelo.addAttribute("hasta", hasta.toString());
        return "compras/lista";
    }

    @GetMapping("/nueva")
    public String nueva(Model modelo) {
        modelo.addAttribute("compra", new Compra());
        return "compras/form";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model modelo, RedirectAttributes aviso) {
        Optional<Compra> compra = servicio.buscar(id);
        if (compra.isEmpty()) {
            aviso.addFlashAttribute("error", "La compra no existe.");
            return "redirect:/compras";
        }
        modelo.addAttribute("compra", compra.get());
        return "compras/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("compra") Compra compra, BindingResult resultado,
                          @RequestParam(required = false) Long proveedorId, RedirectAttributes aviso) {
        Optional<Proveedor> proveedor = (proveedorId == null)
                ? Optional.empty() : servicioProveedores.buscar(proveedorId);
        if (proveedor.isPresent()) {
            compra.setProveedor(proveedor.get());
        } else {
            resultado.rejectValue("proveedor", "requerido", "Elige un proveedor.");
        }
        if (resultado.hasErrors()) {
            return "compras/form";
        }
        servicio.guardar(compra);
        aviso.addFlashAttribute("mensaje", "Compra guardada correctamente.");
        return "redirect:/compras";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes aviso) {
        servicio.eliminar(id);
        aviso.addFlashAttribute("mensaje", "Compra eliminada.");
        return "redirect:/compras";
    }
}