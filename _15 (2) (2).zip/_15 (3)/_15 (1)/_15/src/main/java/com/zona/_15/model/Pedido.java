package com.zona._15.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;

/**
 * Pedido del restaurante (RF002, RF003 y RF006).
 * Viene de la clase Pedido de FastService: cliente, lista de productos con cantidad,
 * fecha, agregarProducto() que junta los repetidos, y calcularTotal().
 */
@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Puede ser null: un pedido en el local no necesita cliente registrado.
    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TipoPedido tipo = TipoPedido.LOCAL;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoPedido estado = EstadoPedido.RECIBIDO;

    @Column(nullable = false)
    private LocalDateTime fecha = LocalDateTime.now();

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id ASC")
    private List<DetallePedido> detalles = new ArrayList<>();



        // Mesa del local en la que se sienta el cliente (solo pedidos "Para el local").
    @ManyToOne
    @JoinColumn(name = "mesa_id")
    private Mesa mesa;

    // true mientras el cliente está sentado en la mesa; pasa a false cuando se va.
    private Boolean mesaEnUso;

        // Barrio de entrega (solo pedidos a domicilio). Se guarda el nombre del barrio.
    @Column(length = 60)
    private String zonaEntrega;

    public Pedido() {
    }

    // Igual que agregarProducto() de FastService: si el producto ya está, suma la cantidad.
    public void agregarProducto(Producto producto, int cantidad) {
        for (DetallePedido d : detalles) {
            if (d.getProducto().getId().equals(producto.getId())) {
                d.setCantidad(d.getCantidad() + cantidad);
                return;
            }
        }
        detalles.add(new DetallePedido(this, producto, cantidad));
    }

    public void quitarDetalle(Long detalleId) {
        detalles.removeIf(d -> d.getId().equals(detalleId));
    }

    // Igual que calcularTotal() de FastService: suma los subtotales.
    public int getTotal() {
        return detalles.stream().mapToInt(DetallePedido::getSubtotal).sum();
    }

    public String getFechaTexto() {
        return fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

    }




        public Mesa getMesa() { return mesa; }
    public void setMesa(Mesa mesa) { this.mesa = mesa; }

    public boolean isMesaEnUso() { return Boolean.TRUE.equals(mesaEnUso); }
    public void setMesaEnUso(boolean mesaEnUso) { this.mesaEnUso = mesaEnUso; }

        public String getZonaEntrega() { return zonaEntrega; }
    public void setZonaEntrega(String zonaEntrega) { this.zonaEntrega = zonaEntrega; }

    public Long getId() { return id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public TipoPedido getTipo() { return tipo; }
    public void setTipo(TipoPedido tipo) { this.tipo = tipo; }

    public EstadoPedido getEstado() { return estado; }
    public void setEstado(EstadoPedido estado) { this.estado = estado; }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }

    public List<DetallePedido> getDetalles() { return detalles; }
}