package com.zona._15.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Mesa;
import com.zona._15.service.MesaService;

import jakarta.validation.Valid;

/** Mesas del local: crearlas, eliminarlas, asignarlas a un pedido y liberarlas. */
@Controller
public class MesaController {

    private final MesaService servicio;

    public MesaController(MesaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/mesas")
    public String listar(Model modelo) {
        modelo.addAttribute("mesa", new Mesa());
        modelo.addAttribute("estados", servicio.listarConEstado());
        return "mesas";
    }

    @PostMapping("/mesas/guardar")
    public String guardar(@Valid @ModelAttribute("mesa") Mesa mesa, BindingResult resultado,
                          Model modelo, RedirectAttributes aviso) {
        if (!resultado.hasFieldErrors("numero") && servicio.numeroEnUso(mesa.getNumero())) {
            resultado.rejectValue("numero", "repetido", "Ya existe una mesa con ese número.");
        }
        if (resultado.hasErrors()) {
            modelo.addAttribute("estados", servicio.listarConEstado());
            return "mesas";
        }
        servicio.guardar(mesa);
        aviso.addFlashAttribute("mensaje", "Mesa guardada correctamente.");
        return "redirect:/mesas";
    }

    @PostMapping("/mesas/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes aviso) {
        try {
            servicio.eliminar(id);
            aviso.addFlashAttribute("mensaje", "Mesa eliminada.");
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/mesas";
    }

    // El cliente se fue: la mesa queda libre. Se puede pedir desde Mesas o desde Cocina.
    @PostMapping("/mesas/{id}/liberar")
    public String liberar(@PathVariable Long id, @RequestParam(required = false) String volver,
                          RedirectAttributes aviso) {
        servicio.liberarMesa(id);
        aviso.addFlashAttribute("mensaje", "Mesa liberada.");
        return "cocina".equals(volver) ? "redirect:/cocina" : "redirect:/mesas";
    }

    @PostMapping("/pedidos/{id}/mesa")
    public String asignar(@PathVariable Long id, @RequestParam(required = false) Long mesaId,
                          RedirectAttributes aviso) {
        if (mesaId == null) {
            aviso.addFlashAttribute("error", "Elige una mesa.");
            return "redirect:/pedidos/" + id;
        }
        try {
            servicio.asignar(id, mesaId);
            aviso.addFlashAttribute("mensaje", "Mesa asignada.");
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }

    @PostMapping("/pedidos/{id}/liberar-mesa")
    public String liberarDePedido(@PathVariable Long id, RedirectAttributes aviso) {
        try {
            servicio.liberarDePedido(id);
            aviso.addFlashAttribute("mensaje", "Mesa liberada.");
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }
}