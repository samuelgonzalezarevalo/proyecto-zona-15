package com.zona._15.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Rol;
import com.zona._15.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByUsername(String username);

    boolean existsByUsername(String username);

    boolean existsByRol(Rol rol);

    // Los más nuevos primero.
    List<Usuario> findAllByOrderByCreadoDesc();
}