package com.zona._15.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.model.Mesa;
import com.zona._15.model.MesaEstado;
import com.zona._15.model.Pedido;
import com.zona._15.model.TipoPedido;
import com.zona._15.repository.MesaRepository;
import com.zona._15.repository.PedidoRepository;

/**
 * Mesas del local. Una mesa está "en uso" mientras haya un pedido suyo con el cliente sentado;
 * queda libre cuando se marca que el cliente se fue (o si el pedido se cancela).
 */
@Service
public class MesaService {

    private final MesaRepository mesas;
    private final PedidoRepository pedidos;

    public MesaService(MesaRepository mesas, PedidoRepository pedidos) {
        this.mesas = mesas;
        this.pedidos = pedidos;
    }

    // Todas las mesas con su estado (libre o en uso, y por qué pedido).
    public List<MesaEstado> listarConEstado() {
        Map<Long, Long> enUso = new HashMap<>();
        for (Pedido p : pedidos.findByMesaEnUsoTrue()) {
            if (p.getMesa() != null) {
                enUso.put(p.getMesa().getId(), p.getId());
            }
        }
        List<MesaEstado> lista = new ArrayList<>();
        for (Mesa mesa : mesas.findAllByOrderByNumeroAsc()) {
            lista.add(new MesaEstado(mesa, enUso.get(mesa.getId())));
        }
        return lista;
    }

    public List<Mesa> disponibles() {
        return listarConEstado().stream()
                .filter(estado -> !estado.isOcupada())
                .map(MesaEstado::getMesa)
                .toList();
    }

    public boolean numeroEnUso(Integer numero) {
        return mesas.existsByNumero(numero);
    }

    public Mesa guardar(Mesa mesa) {
        return mesas.save(mesa);
    }

    @Transactional
    public void eliminar(Long mesaId) {
        if (pedidos.existsByMesaIdAndMesaEnUsoTrue(mesaId)) {
            throw new IllegalArgumentException("La mesa está en uso. Libérala antes de eliminarla.");
        }
        pedidos.quitarMesa(mesaId);
        mesas.deleteById(mesaId);
    }

    // Sienta al cliente de un pedido en una mesa libre.
    @Transactional
    public void asignar(Long pedidoId, Long mesaId) {
        Pedido pedido = pedidos.findById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("El pedido no existe."));
        if (pedido.getTipo() != TipoPedido.LOCAL) {
            throw new IllegalArgumentException("Solo los pedidos para el local usan mesa.");
        }
        if (pedido.getEstado().isCancelado()) {
            throw new IllegalArgumentException("El pedido está cancelado.");
        }
        if (pedido.isMesaEnUso()) {
            throw new IllegalArgumentException("Este pedido ya tiene una mesa en uso.");
        }
        Mesa mesa = mesas.findById(mesaId)
                .orElseThrow(() -> new IllegalArgumentException("La mesa no existe."));
        if (pedidos.existsByMesaIdAndMesaEnUsoTrue(mesaId)) {
            throw new IllegalArgumentException("Esa mesa ya está ocupada. Elige otra.");
        }
        pedido.setMesa(mesa);
        pedido.setMesaEnUso(true);
    }

    // El cliente se fue: la mesa queda libre.
    @Transactional
    public void liberarMesa(Long mesaId) {
        for (Pedido pedido : pedidos.findByMesaIdAndMesaEnUsoTrue(mesaId)) {
            pedido.setMesaEnUso(false);
        }
    }

    @Transactional
    public void liberarDePedido(Long pedidoId) {
        Pedido pedido = pedidos.findById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("El pedido no existe."));
        if (!pedido.isMesaEnUso()) {
            throw new IllegalArgumentException("Este pedido no tiene una mesa en uso.");
        }
        pedido.setMesaEnUso(false);
    }
}