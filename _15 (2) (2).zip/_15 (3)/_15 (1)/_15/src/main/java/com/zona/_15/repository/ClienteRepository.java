package com.zona._15.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    Optional<Cliente> findByTelefono(String telefono);

    List<Cliente> findByNombreContainingIgnoreCaseOrTelefonoContaining(
            String nombre, String telefono, Sort orden);
}