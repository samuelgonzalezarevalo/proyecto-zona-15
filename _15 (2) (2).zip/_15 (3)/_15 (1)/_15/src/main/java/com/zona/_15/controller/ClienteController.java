package com.zona._15.controller;

import java.util.Optional;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.Cliente;
import com.zona._15.service.ClienteService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService servicio;

    public ClienteController(ClienteService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String q, Model modelo) {
        modelo.addAttribute("clientes", servicio.listar(q));
        modelo.addAttribute("q", q);
        return "clientes/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model modelo) {
        modelo.addAttribute("cliente", new Cliente());
        return "clientes/form";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model modelo, RedirectAttributes aviso) {
        Optional<Cliente> cliente = servicio.buscar(id);
        if (cliente.isEmpty()) {
            aviso.addFlashAttribute("error", "El cliente no existe.");
            return "redirect:/clientes";
        }
        modelo.addAttribute("cliente", cliente.get());
        return "clientes/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("cliente") Cliente cliente,
                          BindingResult resultado, RedirectAttributes aviso) {
        if (!resultado.hasFieldErrors("telefono") && servicio.telefonoDuplicado(cliente)) {
            resultado.rejectValue("telefono", "duplicado", "Ya existe un cliente con ese teléfono.");
        }
        if (resultado.hasErrors()) {
            return "clientes/form";
        }
        servicio.guardar(cliente);
        aviso.addFlashAttribute("mensaje", "Cliente guardado correctamente.");
        return "redirect:/clientes";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes aviso) {
        try {
            servicio.eliminar(id);
            aviso.addFlashAttribute("mensaje", "Cliente eliminado.");
        } catch (DataIntegrityViolationException e) {
            aviso.addFlashAttribute("error", "No se puede eliminar: el cliente ya tiene pedidos.");
        }
        return "redirect:/clientes";
    }
}