package com.zona._15.model;

public enum EstadoPedido {
    RECIBIDO("Recibido", "Empezar a preparar"),
    EN_PREPARACION("En preparación", "Marcar como listo"),
    LISTO("Listo", "Marcar como entregado"),
    ENTREGADO("Entregado", null),
    CANCELADO("Cancelado", null);

    private final String etiqueta;
    private final String accion;

    EstadoPedido(String etiqueta, String accion) {
        this.etiqueta = etiqueta;
        this.accion = accion;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    // Texto del botón que pasa el pedido al siguiente estado (null si ya no hay siguiente).
    public String getAccion() {
        return accion;
    }

    // Siguiente estado del pedido: Recibido -> En preparación -> Listo -> Entregado.
    public EstadoPedido siguiente() {
        return switch (this) {
            case RECIBIDO -> EN_PREPARACION;
            case EN_PREPARACION -> LISTO;
            case LISTO -> ENTREGADO;
            default -> null;
        };
    }

    // Solo se puede modificar o cancelar antes de que pase a preparación.
    public boolean isModificable() {
        return this == RECIBIDO;
    }

    public boolean isCancelable() {
        return this == RECIBIDO;
    }

    public boolean isCancelado() {
        return this == CANCELADO;
    }
}