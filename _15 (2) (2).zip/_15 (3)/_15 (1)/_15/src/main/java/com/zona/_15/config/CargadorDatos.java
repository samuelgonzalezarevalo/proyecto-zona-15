package com.zona._15.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.zona._15.model.Producto;
import com.zona._15.repository.ProductoRepository;

@Component
public class CargadorDatos implements CommandLineRunner {

    private final ProductoRepository productos;

    public CargadorDatos(ProductoRepository productos) {
        this.productos = productos;
    }

    @Override
    public void run(String... args) {
        if (productos.count() > 0) {
            return;
        }
        List<Producto> lista = new ArrayList<>();

        // PIZZETAS
        agregar(lista, "PIZZETA CLÁSICA", 11000, "PIZZETAS");
        agregar(lista, "PIZZETA HAWAIANA", 12000, "PIZZETAS");
        agregar(lista, "PIZZETA POLLO Y MAÍZ", 15000, "PIZZETAS");
        agregar(lista, "PIZZETA CHORIZZZA", 13000, "PIZZETAS");
        agregar(lista, "PIZZETA BUTTIPIZZA", 13000, "PIZZETAS");
        agregar(lista, "PIZZETA VEGETARIANA", 13000, "PIZZETAS");
        // PIZZAS
        agregar(lista, "PIZZA CLÁSICA - PEQUEÑA", 20000, "PIZZAS");
        agregar(lista, "PIZZA CLÁSICA - MEDIANA", 34000, "PIZZAS");
        agregar(lista, "PIZZA CLÁSICA - EXTRA", 46000, "PIZZAS");
        agregar(lista, "PIZZA HAWAIANA - PEQUEÑA", 22000, "PIZZAS");
        agregar(lista, "PIZZA HAWAIANA - MEDIANA", 40000, "PIZZAS");
        agregar(lista, "PIZZA HAWAIANA - EXTRA", 50000, "PIZZAS");
        agregar(lista, "PIZZA VEGETARIANA - PEQUEÑA", 27000, "PIZZAS");
        agregar(lista, "PIZZA VEGETARIANA - MEDIANA", 42000, "PIZZAS");
        agregar(lista, "PIZZA VEGETARIANA - EXTRA", 55000, "PIZZAS");
        // PIZZAS ESPECIALES
        agregar(lista, "LAS ACACIAS - PEQUEÑA", 35000, "PIZZAS ESPECIALES");
        agregar(lista, "LAS ACACIAS - MEDIANA", 50000, "PIZZAS ESPECIALES");
        agregar(lista, "LAS ACACIAS - EXTRA", 66000, "PIZZAS ESPECIALES");
        agregar(lista, "POLLO Y TOCINETA - PEQUEÑA", 30000, "PIZZAS ESPECIALES");
        agregar(lista, "POLLO Y TOCINETA - MEDIANA", 46000, "PIZZAS ESPECIALES");
        agregar(lista, "POLLO Y TOCINETA - EXTRA", 62000, "PIZZAS ESPECIALES");
        agregar(lista, "HAWAIANA ESPECIAL - PEQUEÑA", 26000, "PIZZAS ESPECIALES");
        agregar(lista, "HAWAIANA ESPECIAL - MEDIANA", 44000, "PIZZAS ESPECIALES");
        agregar(lista, "HAWAIANA ESPECIAL - EXTRA", 55000, "PIZZAS ESPECIALES");
        // HAMBURGUESAS
        agregar(lista, "HAMBURGUESA CLÁSICA", 14000, "HAMBURGUESAS");
        agregar(lista, "BURGUER ZONA", 20000, "HAMBURGUESAS");
        agregar(lista, "BACON CHEESE", 18000, "HAMBURGUESAS");
        agregar(lista, "CHICKEN CHEESE", 18000, "HAMBURGUESAS");
        // PERROS
        agregar(lista, "SUPER PERRO", 10000, "PERROS");
        agregar(lista, "3X SUPER PERRO (PROMO)", 28000, "PERROS");
        agregar(lista, "CHORIPERRO", 14000, "PERROS");
        agregar(lista, "SUIZO", 14000, "PERROS");
        agregar(lista, "REMIX", 14000, "PERROS");
        agregar(lista, "PERRO ZONA", 16000, "PERROS");
        agregar(lista, "PERRO SALVAJE", 23000, "PERROS");
        // PICADAS
        agregar(lista, "PICADA PERSONAL", 22000, "PICADAS");
        agregar(lista, "PICADA 2 PAX", 30000, "PICADAS");
        agregar(lista, "PICADA 3-4 PAX", 40000, "PICADAS");
        agregar(lista, "PICADA SALVAJE", 90000, "PICADAS");
        // SALCHIPAPAS
        agregar(lista, "SALCHIPAPA", 12000, "SALCHIPAPAS");
        agregar(lista, "CHORIPAPA", 14000, "SALCHIPAPAS");
        agregar(lista, "BUTTIPAPAS", 14000, "SALCHIPAPAS");
        // ASADOS
        agregar(lista, "PECHUGA", 19000, "ASADOS");
        agregar(lista, "PECHUGA GRATINADA", 22000, "ASADOS");
        agregar(lista, "PATACÓN CON TODO", 20000, "ASADOS");
        // AREPAS
        agregar(lista, "AREPA SOLO QUESO", 6500, "AREPAS");
        agregar(lista, "AREPA BUTIFARRA", 9000, "AREPAS");
        agregar(lista, "AREPA CHORIZO", 9000, "AREPAS");
        agregar(lista, "AREPA CHICHARRÓN", 9000, "AREPAS");
        agregar(lista, "AREPA CARNE", 10000, "AREPAS");
        agregar(lista, "AREPA POLLO", 9000, "AREPAS");
        agregar(lista, "AREPA MIXTA", 12000, "AREPAS");
        // COMBOS
        agregar(lista, "COMBO FAMILIAR", 53000, "COMBOS");
        agregar(lista, "COMBO AMIGOS", 60000, "COMBOS");
        agregar(lista, "ZONA TRIPLE", 66000, "COMBOS");
        agregar(lista, "EL PODER DEL TRES", 55000, "COMBOS");

        productos.saveAll(lista);
    }

    private void agregar(List<Producto> lista, String nombre, int precio, String categoria) {
        lista.add(new Producto(nombre, precio, categoria));
    }
}