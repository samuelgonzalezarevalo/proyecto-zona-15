package com.zona._15.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.zona._15.model.Compra;
import com.zona._15.repository.CompraRepository;

@Service
public class CompraService {

    private final CompraRepository repositorio;

    public CompraService(CompraRepository repositorio) {
        this.repositorio = repositorio;
    }

    public List<Compra> listar(LocalDate desde, LocalDate hasta) {
        return repositorio.findByFechaBetweenOrderByFechaDescIdDesc(desde, hasta);
    }

    public Optional<Compra> buscar(Long id) {
        return repositorio.findById(id);
    }

    public Compra guardar(Compra compra) {
        return repositorio.save(compra);
    }

    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }
}