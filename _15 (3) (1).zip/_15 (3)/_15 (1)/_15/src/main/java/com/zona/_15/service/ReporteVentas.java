package com.zona._15.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;


public class ReporteVentas {

    private final LocalDate desde;
    private final LocalDate hasta;
    private final int cantidadFacturas;
    private final int totalVentas;
    private final List<PorMetodo> porMetodo;
    private final List<PorProducto> porProducto;

    public ReporteVentas(LocalDate desde, LocalDate hasta, int cantidadFacturas, int totalVentas,
                         List<PorMetodo> porMetodo, List<PorProducto> porProducto) {
        this.desde = desde;
        this.hasta = hasta;
        this.cantidadFacturas = cantidadFacturas;
        this.totalVentas = totalVentas;
        this.porMetodo = porMetodo;
        this.porProducto = porProducto;
    }

    public int getTicketPromedio() {
        return cantidadFacturas == 0 ? 0 : totalVentas / cantidadFacturas;
    }

    public String getRangoTexto() {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        if (desde.equals(hasta)) {
            return desde.format(formato);
        }
        return desde.format(formato) + " al " + hasta.format(formato);
    }

    public int getCantidadFacturas() { return cantidadFacturas; }
    public int getTotalVentas() { return totalVentas; }
    public List<PorMetodo> getPorMetodo() { return porMetodo; }
    public List<PorProducto> getPorProducto() { return porProducto; }

    /** Ventas de un método de pago. */
    public static class PorMetodo {
        private final String metodo;
        private int cantidad;
        private int total;

        public PorMetodo(String metodo) {
            this.metodo = metodo;
        }

        public void sumar(int valor) {
            cantidad++;
            total += valor;
        }

        public String getMetodo() { return metodo; }
        public int getCantidad() { return cantidad; }
        public int getTotal() { return total; }
    }

    /** Ventas de un producto: cuántas unidades se vendieron y cuánto dinero dejaron. */
    public static class PorProducto {
        private final String nombre;
        private final String categoria;
        private int cantidad;
        private int ingresos;

        public PorProducto(String nombre, String categoria) {
            this.nombre = nombre;
            this.categoria = categoria;
        }

        public void sumar(int unidades, int dinero) {
            cantidad += unidades;
            ingresos += dinero;
        }

        public String getNombre() { return nombre; }
        public String getCategoria() { return categoria; }
        public int getCantidad() { return cantidad; }
        public int getIngresos() { return ingresos; }
    }
}
