package com.zona._15.service;

import java.util.Map;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public final class CodigoQr {

    private CodigoQr() {
    }

    public static String svg(String texto) {
        try {
            BitMatrix matriz = new QRCodeWriter().encode(texto, BarcodeFormat.QR_CODE, 0, 0,
                    Map.of(EncodeHintType.MARGIN, 1, EncodeHintType.CHARACTER_SET, "UTF-8"));
            int lado = matriz.getWidth();
            StringBuilder svg = new StringBuilder();
            svg.append("<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"qr\" viewBox=\"0 0 ")
                    .append(lado).append(' ').append(lado).append("\" shape-rendering=\"crispEdges\">");
            svg.append("<rect width=\"").append(lado).append("\" height=\"").append(lado).append("\" fill=\"#fff\"/>");
            svg.append("<path fill=\"#000\" d=\"");
            for (int y = 0; y < lado; y++) {
                for (int x = 0; x < lado; x++) {
                    if (matriz.get(x, y)) {
                        svg.append('M').append(x).append(' ').append(y).append("h1v1h-1z");
                    }
                }
            }
            svg.append("\"/></svg>");
            return svg.toString();
        } catch (WriterException e) {
            return "";
        }
    }
}