package com.zona._15.controller;

import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.model.MetodoPago;
import com.zona._15.model.Pedido;
import com.zona._15.model.TipoPedido;
import com.zona._15.service.ClienteService;
import com.zona._15.service.FacturaService;
import com.zona._15.service.MesaService;
import com.zona._15.service.PedidoService;
import com.zona._15.service.ProductoService;
import com.zona._15.service.ZonaService;

@Controller
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService servicio;
    private final ClienteService clientes;
    private final ProductoService productos;
    private final FacturaService facturas;
    private final MesaService servicioMesas;
    private final ZonaService servicioZonas;

    public PedidoController(PedidoService servicio, ClienteService clientes,
                            ProductoService productos, FacturaService facturas,
                            MesaService servicioMesas, ZonaService servicioZonas) {
        this.servicio = servicio;
        this.clientes = clientes;
        this.productos = productos;
        this.facturas = facturas;
        this.servicioMesas = servicioMesas;
        this.servicioZonas = servicioZonas;
    }

    @GetMapping
    public String listar(Model modelo) {
        modelo.addAttribute("pedidos", servicio.listar());
        return "pedidos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model modelo) {
        modelo.addAttribute("clientes", clientes.listar(null));
        modelo.addAttribute("tipos", TipoPedido.values());
        modelo.addAttribute("mesas", servicioMesas.disponibles());
        modelo.addAttribute("zonas", servicioZonas.listar());
        return "pedidos/form";
    }

    @PostMapping("/crear")
    public String crear(@RequestParam(required = false) Long clienteId,
                        @RequestParam TipoPedido tipo,
                        @RequestParam(required = false) Long mesaId,
                        @RequestParam(required = false) Long zonaId, RedirectAttributes aviso) {
        if (tipo == TipoPedido.DOMICILIO && clienteId == null) {
            aviso.addFlashAttribute("error", "Un pedido a domicilio necesita un cliente.");
            return "redirect:/pedidos/nuevo";
        }
        try {
            Pedido pedido = servicio.crear(clienteId, tipo, mesaId, zonaId);
            return "redirect:/pedidos/" + pedido.getId();
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
            return "redirect:/pedidos/nuevo";
        }
    }

    @GetMapping("/{id}")
    public String detalle(@PathVariable Long id, Model modelo, RedirectAttributes aviso) {
        Optional<Pedido> pedido = servicio.buscar(id);
        if (pedido.isEmpty()) {
            aviso.addFlashAttribute("error", "El pedido no existe.");
            return "redirect:/pedidos";
        }
        modelo.addAttribute("pedido", pedido.get());
        modelo.addAttribute("productos", productos.listar(null));
        modelo.addAttribute("metodos", MetodoPago.values());
        modelo.addAttribute("factura", facturas.buscarPorPedido(id).orElse(null));
        modelo.addAttribute("mesas", servicioMesas.disponibles());
        return "pedidos/detalle";
    }

    @PostMapping("/{id}/items")
    public String agregar(@PathVariable Long id, @RequestParam Long productoId,
                          @RequestParam(defaultValue = "1") int cantidad, RedirectAttributes aviso) {
        if (cantidad < 1 || cantidad > 99) {
            aviso.addFlashAttribute("error", "La cantidad debe estar entre 1 y 99.");
            return "redirect:/pedidos/" + id;
        }
        try {
            servicio.agregarProducto(id, productoId, cantidad);
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }

    @PostMapping("/{id}/items/{detalleId}/eliminar")
    public String quitar(@PathVariable Long id, @PathVariable Long detalleId, RedirectAttributes aviso) {
        try {
            servicio.quitarDetalle(id, detalleId);
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }

    @PostMapping("/{id}/avanzar")
    public String avanzar(@PathVariable Long id, @RequestParam(required = false) String volver,
                          RedirectAttributes aviso) {
        try {
            servicio.avanzar(id);
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "cocina".equals(volver) ? "redirect:/cocina" : "redirect:/pedidos/" + id;
    }

    @PostMapping("/{id}/cancelar")
    public String cancelar(@PathVariable Long id, RedirectAttributes aviso) {
        try {
            servicio.cancelar(id);
            aviso.addFlashAttribute("mensaje", "Pedido cancelado.");
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }
}