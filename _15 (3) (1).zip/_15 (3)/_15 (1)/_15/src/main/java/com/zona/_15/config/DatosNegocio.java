package com.zona._15.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties(prefix = "zona15.negocio")
public class DatosNegocio {

    private static final String POR_CONFIGURAR = "Por configurar";

    private String nombre = "ZONA 15";
    private String nit;
    private String regimen;
    private String direccion;
    private String telefono;
    private String resolucion;
    private String impuestoNombre = "Impuesto nacional al consumo";
    private int impuestoPorcentaje = 0;
    private String nota;

    private String valor(String texto) {
        return (texto == null || texto.isBlank()) ? POR_CONFIGURAR : texto.trim();
    }

    public String getNombre() { return valor(nombre); }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getNit() { return valor(nit); }
    public void setNit(String nit) { this.nit = nit; }

    public String getRegimen() { return valor(regimen); }
    public void setRegimen(String regimen) { this.regimen = regimen; }

    public String getDireccion() { return valor(direccion); }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getTelefono() { return valor(telefono); }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getResolucion() { return valor(resolucion); }
    public void setResolucion(String resolucion) { this.resolucion = resolucion; }

    public String getImpuestoNombre() { return valor(impuestoNombre); }
    public void setImpuestoNombre(String impuestoNombre) { this.impuestoNombre = impuestoNombre; }

    public int getImpuestoPorcentaje() { return impuestoPorcentaje; }
    public void setImpuestoPorcentaje(int impuestoPorcentaje) { this.impuestoPorcentaje = impuestoPorcentaje; }

    public String getNota() { return (nota == null || nota.isBlank()) ? null : nota.trim(); }
    public void setNota(String nota) { this.nota = nota; }
}