package com.zona._15.model;

public enum EstadoPedido {
    RECIBIDO("Recibido", "Empezar a preparar"),
    EN_PREPARACION("En preparación", "Marcar como listo"),
    LISTO("Listo", "Marcar como entregado"),
    ENTREGADO("Entregado", null),
    CANCELADO("Cancelado", null);

    private final String etiqueta;
    private final String accion;

    EstadoPedido(String etiqueta, String accion) {
        this.etiqueta = etiqueta;
        this.accion = accion;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public String getAccion() {
        return accion;
    }

    public EstadoPedido siguiente() {
        return switch (this) {
            case RECIBIDO -> EN_PREPARACION;
            case EN_PREPARACION -> LISTO;
            case LISTO -> ENTREGADO;
            default -> null;
        };
    }

    public boolean isModificable() {
        return this == RECIBIDO;
    }

    public boolean isCancelable() {
        return this == RECIBIDO;
    }

    public boolean isCancelado() {
        return this == CANCELADO;
    }
}