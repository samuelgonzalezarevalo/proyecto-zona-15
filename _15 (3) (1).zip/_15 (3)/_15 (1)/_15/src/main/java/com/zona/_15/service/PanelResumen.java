package com.zona._15.service;

import java.util.List;

public class PanelResumen {

    private final long totalProductos;
    private final long totalClientes;
    private final long pedidosHoy;
    private final int ventasHoy;
    private final List<DiaSemana> semana;
    private final List<EstadoResumen> estados;
    private final String gradiente;
    private final List<FilaPedido> recientes;
    private final List<FilaPedido> enProceso;

    public PanelResumen(long totalProductos, long totalClientes, long pedidosHoy, int ventasHoy,
                        List<DiaSemana> semana, List<EstadoResumen> estados, String gradiente,
                        List<FilaPedido> recientes, List<FilaPedido> enProceso) {
        this.totalProductos = totalProductos;
        this.totalClientes = totalClientes;
        this.pedidosHoy = pedidosHoy;
        this.ventasHoy = ventasHoy;
        this.semana = semana;
        this.estados = estados;
        this.gradiente = gradiente;
        this.recientes = recientes;
        this.enProceso = enProceso;
    }

    public long getTotalProductos() { return totalProductos; }
    public long getTotalClientes() { return totalClientes; }
    public long getPedidosHoy() { return pedidosHoy; }
    public int getVentasHoy() { return ventasHoy; }
    public List<DiaSemana> getSemana() { return semana; }
    public List<EstadoResumen> getEstados() { return estados; }
    public String getGradiente() { return gradiente; }
    public List<FilaPedido> getRecientes() { return recientes; }
    public List<FilaPedido> getEnProceso() { return enProceso; }

    
    public static class DiaSemana {
        private final String etiqueta;
        private final long cantidad;
        private final int porcentaje;

        public DiaSemana(String etiqueta, long cantidad, int porcentaje) {
            this.etiqueta = etiqueta;
            this.cantidad = cantidad;
            this.porcentaje = porcentaje;
        }

        public String getEtiqueta() { return etiqueta; }
        public long getCantidad() { return cantidad; }
        public int getPorcentaje() { return porcentaje; }
    }

    public static class EstadoResumen {
        private final String etiqueta;
        private final long cantidad;
        private final int porcentaje;
        private final String color;

        public EstadoResumen(String etiqueta, long cantidad, int porcentaje, String color) {
            this.etiqueta = etiqueta;
            this.cantidad = cantidad;
            this.porcentaje = porcentaje;
            this.color = color;
        }

        public String getEtiqueta() { return etiqueta; }
        public long getCantidad() { return cantidad; }
        public int getPorcentaje() { return porcentaje; }
        public String getColor() { return color; }
    }

    public static class FilaPedido {
        private final Long id;
        private final String cliente;
        private final String estadoEtiqueta;
        private final String estadoClase;
        private final int total;
        private final String hora;

        public FilaPedido(Long id, String cliente, String estadoEtiqueta, String estadoClase,
                          int total, String hora) {
            this.id = id;
            this.cliente = cliente;
            this.estadoEtiqueta = estadoEtiqueta;
            this.estadoClase = estadoClase;
            this.total = total;
            this.hora = hora;
        }

        public Long getId() { return id; }
        public String getCliente() { return cliente; }
        public String getEstadoEtiqueta() { return estadoEtiqueta; }
        public String getEstadoClase() { return estadoClase; }
        public int getTotal() { return total; }
        public String getHora() { return hora; }
    }
}