package com.zona._15.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.config.DatosNegocio;
import com.zona._15.model.Factura;
import com.zona._15.model.MetodoPago;
import com.zona._15.model.Pedido;
import com.zona._15.repository.FacturaRepository;
import com.zona._15.repository.PedidoRepository;

@Service
public class FacturaService {

    private final FacturaRepository facturas;
    private final PedidoRepository pedidos;
    private final DatosNegocio negocio;

    public FacturaService(FacturaRepository facturas, PedidoRepository pedidos, DatosNegocio negocio) {
        this.facturas = facturas;
        this.pedidos = pedidos;
        this.negocio = negocio;
    }

    public List<Factura> listar() {
        return facturas.findAllByOrderByFechaDesc();
    }

    public Optional<Factura> buscar(Long id) {
        return facturas.findConPedidoById(id);
    }

    public Optional<Factura> buscarPorPedido(Long pedidoId) {
        return facturas.findByPedidoId(pedidoId);
    }

    @Transactional
    public Factura facturar(Long pedidoId, MetodoPago metodoPago, String identificacion) {
        Pedido pedido = pedidos.findConDetallesById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("El pedido no existe."));
        if (pedido.getEstado().isCancelado()) {
            throw new IllegalArgumentException("No se puede cobrar un pedido cancelado.");
        }
        if (facturas.existsByPedidoId(pedidoId)) {
            throw new IllegalArgumentException("Este pedido ya fue cobrado.");
        }
        if (pedido.getDetalles().isEmpty()) {
            throw new IllegalArgumentException("Agrega al menos un producto antes de cobrar.");
        }
        String idCliente = limpiarIdentificacion(identificacion);

        int total = pedido.getTotal();
        int porcentaje = negocio.getImpuestoPorcentaje();
        int subtotal = (porcentaje <= 0) ? total : (int) Math.round(total / (1 + porcentaje / 100.0));
        int impuesto = total - subtotal;

        Factura factura = facturas.save(
                new Factura(pedido, subtotal, impuesto, Math.max(porcentaje, 0), total, metodoPago, idCliente));
        factura.setCufe(calcularCufe(factura));
        return factura;
    }

    private String limpiarIdentificacion(String identificacion) {
        if (identificacion == null || identificacion.isBlank()) {
            return null;
        }
        String texto = identificacion.trim();
        if (!texto.matches("^[0-9.\\-]{5,20}$")) {
            throw new IllegalArgumentException(
                    "La identificación solo puede tener números, puntos y guion (de 5 a 20 caracteres).");
        }
        return texto;
    }

    
    private String calcularCufe(Factura f) {
        String texto = f.getNumero()
                + f.getFecha().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                + f.getFecha().format(DateTimeFormatter.ofPattern("HH:mm:ss"))
                + dinero(f.getSubtotal()) + "01" + dinero(f.getImpuesto()) + dinero(f.getTotal())
                + negocio.getNit()
                + (f.getIdentificacionCliente() == null ? "" : f.getIdentificacionCliente())
                + "CLAVE-TECNICA-DE-PRACTICA" + "2";
        try {
            byte[] huella = MessageDigest.getInstance("SHA-384").digest(texto.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(huella);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("No se pudo calcular el CUFE.", e);
        }
    }

    private String dinero(int valor) {
        return String.format(Locale.ROOT, "%.2f", (double) valor);
    }
}