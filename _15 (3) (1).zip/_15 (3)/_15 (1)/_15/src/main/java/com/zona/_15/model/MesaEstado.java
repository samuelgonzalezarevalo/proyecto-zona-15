package com.zona._15.model;

public class MesaEstado {

    private final Mesa mesa;
    private final Long pedidoId;

    public MesaEstado(Mesa mesa, Long pedidoId) {
        this.mesa = mesa;
        this.pedidoId = pedidoId;
    }

    public boolean isOcupada() {
        return pedidoId != null;
    }

    public Mesa getMesa() { return mesa; }

    public Long getPedidoId() { return pedidoId; }
}