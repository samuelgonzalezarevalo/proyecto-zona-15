package com.zona._15.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Compra;

public interface CompraRepository extends JpaRepository<Compra, Long> {

    List<Compra> findByFechaBetweenOrderByFechaDescIdDesc(LocalDate desde, LocalDate hasta);
}