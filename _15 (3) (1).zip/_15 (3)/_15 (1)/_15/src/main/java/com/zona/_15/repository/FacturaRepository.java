package com.zona._15.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import com.zona._15.model.Factura;

public interface FacturaRepository extends JpaRepository<Factura, Long> {

    boolean existsByPedidoId(Long pedidoId);

    Optional<Factura> findByPedidoId(Long pedidoId);

    @EntityGraph(attributePaths = {"pedido", "pedido.cliente", "pedido.detalles", "pedido.detalles.producto"})
    Optional<Factura> findConPedidoById(Long id);

    @EntityGraph(attributePaths = {"pedido", "pedido.cliente"})
    List<Factura> findAllByOrderByFechaDesc();

    @EntityGraph(attributePaths = {"pedido", "pedido.detalles", "pedido.detalles.producto"})
    List<Factura> findByFechaGreaterThanEqualAndFechaLessThanOrderByFechaAsc(
            LocalDateTime desde, LocalDateTime hasta);
}