package com.zona._15.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SeguridadConfig {

    @Bean
    public PasswordEncoder codificadorDeClaves() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filtroDeSeguridad(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(reglas -> reglas
                            .requestMatchers("/css/**", "/img/**", "/login", "/registro", "/error").permitAll()
                .requestMatchers("/menu", "/carrito", "/carrito/**", "/mis-pedidos", "/mis-pedidos/**")
                    .hasRole("USUARIO")
                .anyRequest().hasRole("ADMIN"))
            .formLogin(inicio -> inicio
                .loginPage("/login")
                .successHandler((solicitud, respuesta, autenticacion) ->
                        respuesta.sendRedirect(solicitud.getContextPath() + paginaInicial(autenticacion))))
            .logout(salida -> salida.logoutSuccessUrl("/login?salio"))
            .exceptionHandling(errores -> errores
                // Si alguien entra a una página que no le corresponde, vuelve a la suya.
                .accessDeniedHandler((solicitud, respuesta, error) ->
                        respuesta.sendRedirect(solicitud.getContextPath()
                                + paginaInicial(SecurityContextHolder.getContext().getAuthentication()))));
        return http.build();
    }

    private static String paginaInicial(Authentication autenticacion) {
        boolean esAdmin = autenticacion != null && autenticacion.getAuthorities().stream()
                .anyMatch(permiso -> permiso.getAuthority().equals("ROLE_ADMIN"));
        return esAdmin ? "/" : "/menu";
    }
}