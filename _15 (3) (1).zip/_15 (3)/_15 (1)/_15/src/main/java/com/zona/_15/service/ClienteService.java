package com.zona._15.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.zona._15.model.Cliente;
import com.zona._15.repository.ClienteRepository;

@Service
public class ClienteService {

    private final ClienteRepository repositorio;

    public ClienteService(ClienteRepository repositorio) {
        this.repositorio = repositorio;
    }

    public List<Cliente> listar(String busqueda) {
        Sort orden = Sort.by("nombre").ascending();
        if (busqueda == null || busqueda.isBlank()) {
            return repositorio.findAll(orden);
        }
        String texto = busqueda.trim();
        return repositorio.findByNombreContainingIgnoreCaseOrTelefonoContaining(texto, texto, orden);
    }

    public Optional<Cliente> buscar(Long id) {
        return repositorio.findById(id);
    }

    public Cliente guardar(Cliente cliente) {
        return repositorio.save(cliente);
    }

    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }

    public boolean telefonoDuplicado(Cliente cliente) {
        Optional<Cliente> existente = repositorio.findByTelefono(cliente.getTelefono());
        if (existente.isEmpty()) {
            return false;
        }
        return cliente.getId() == null || !existente.get().getId().equals(cliente.getId());
    }

    public long contar() {
        return repositorio.count();
    }
}