package com.zona._15.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "facturas")
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    @JoinColumn(name = "pedido_id", nullable = false, unique = true)
    private Pedido pedido;

    @Column(nullable = false)
    private LocalDateTime fecha = LocalDateTime.now();

    @Column(nullable = false)
    private int total;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MetodoPago metodoPago;

    
    private Integer subtotal;

    private Integer impuesto;

    private Integer impuestoPorcentaje;

    @Column(length = 20)
    private String identificacionCliente;

    @Column(length = 96)
    private String cufe;

    public Factura() {
    }

    public Factura(Pedido pedido, int subtotal, int impuesto, int impuestoPorcentaje, int total,
                   MetodoPago metodoPago, String identificacionCliente) {
        this.pedido = pedido;
        this.subtotal = subtotal;
        this.impuesto = impuesto;
        this.impuestoPorcentaje = impuestoPorcentaje;
        this.total = total;
        this.metodoPago = metodoPago;
        this.identificacionCliente = identificacionCliente;
    }

    public String getNumero() {
        return String.format("F-%05d", id);
    }

    public String getFechaTexto() {
        return fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    public int getSubtotal() { return subtotal != null ? subtotal : total; }

    public int getImpuesto() { return impuesto != null ? impuesto : 0; }

    public int getImpuestoPorcentaje() { return impuestoPorcentaje != null ? impuestoPorcentaje : 0; }

    public Long getId() { return id; }

    public Pedido getPedido() { return pedido; }

    public LocalDateTime getFecha() { return fecha; }

    public int getTotal() { return total; }

    public MetodoPago getMetodoPago() { return metodoPago; }

    public String getIdentificacionCliente() { return identificacionCliente; }

    public String getCufe() { return cufe; }
    public void setCufe(String cufe) { this.cufe = cufe; }
}