package com.zona._15.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.model.Cliente;
import com.zona._15.model.Pedido;
import com.zona._15.model.Producto;
import com.zona._15.model.TipoPedido;
import com.zona._15.model.Zona;
import com.zona._15.repository.ClienteRepository;
import com.zona._15.repository.PedidoRepository;
import com.zona._15.repository.ProductoRepository;

@Service
public class MisPedidosService {

    private final PedidoRepository pedidos;
    private final ProductoRepository productos;
    private final ClienteRepository clientes;
    private final ZonaService zonas;

    public MisPedidosService(PedidoRepository pedidos, ProductoRepository productos,
                             ClienteRepository clientes, ZonaService zonas) {
        this.pedidos = pedidos;
        this.productos = productos;
        this.clientes = clientes;
        this.zonas = zonas;
    }

    public List<Pedido> listar(Long clienteId) {
        return pedidos.findByClienteIdOrderByFechaDesc(clienteId);
    }

    public Optional<Pedido> buscarDelCliente(Long pedidoId, Long clienteId) {
        return pedidos.findConDetallesById(pedidoId)
                .filter(p -> p.getCliente() != null && p.getCliente().getId().equals(clienteId));
    }

   
    @Transactional
    public Pedido crear(Long clienteId, TipoPedido tipo, Map<Long, Integer> items, Long zonaId) {
        Cliente cliente = clientes.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Tu cuenta no tiene un cliente asociado."));
        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setTipo(tipo);
        if (tipo == TipoPedido.DOMICILIO) {
            Zona zona = (zonaId == null) ? null : zonas.buscar(zonaId).orElse(null);
            if (zona == null) {
                throw new IllegalArgumentException(
                        "Elige el barrio de entrega. Solo hacemos domicilios en Turbaco.");
            }
            pedido.setZonaEntrega(zona.getNombre());
        }
        for (Map.Entry<Long, Integer> item : items.entrySet()) {
            Producto producto = productos.findById(item.getKey())
                    .orElseThrow(() -> new IllegalArgumentException("Un producto ya no existe."));
            pedido.agregarProducto(producto, item.getValue());
        }
        if (pedido.getDetalles().isEmpty()) {
            throw new IllegalArgumentException("Tu pedido está vacío.");
        }
        return pedidos.save(pedido);
    }
}