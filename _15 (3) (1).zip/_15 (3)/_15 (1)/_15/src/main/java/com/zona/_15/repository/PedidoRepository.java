package com.zona._15.repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zona._15.model.EstadoPedido;
import com.zona._15.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    Optional<Pedido> findConDetallesById(Long id);

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findAllByOrderByFechaDesc();

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findByEstadoInOrderByFechaAsc(Collection<EstadoPedido> estados);

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findByClienteIdOrderByFechaDesc(Long clienteId);

    long countByClienteId(Long clienteId);

    List<Pedido> findByMesaEnUsoTrue();

    List<Pedido> findByMesaIdAndMesaEnUsoTrue(Long mesaId);

    boolean existsByMesaIdAndMesaEnUsoTrue(Long mesaId);

    @Modifying
    @Query("update Pedido p set p.mesa = null where p.mesa.id = :mesaId")
    void quitarMesa(@Param("mesaId") Long mesaId);

    long countByEstado(EstadoPedido estado);

    long countByFechaGreaterThanEqualAndFechaLessThan(LocalDateTime desde, LocalDateTime hasta);

    @EntityGraph(attributePaths = {"cliente", "detalles", "detalles.producto"})
    List<Pedido> findTop5ByOrderByFechaDesc();
}