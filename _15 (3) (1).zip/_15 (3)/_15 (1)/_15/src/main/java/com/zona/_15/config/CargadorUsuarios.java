package com.zona._15.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.zona._15.model.Rol;
import com.zona._15.model.Usuario;
import com.zona._15.repository.UsuarioRepository;

@Component
public class CargadorUsuarios implements CommandLineRunner {

    private final UsuarioRepository usuarios;
    private final PasswordEncoder codificador;
    private final String usuarioAdmin;
    private final String claveAdmin;

    public CargadorUsuarios(UsuarioRepository usuarios, PasswordEncoder codificador,
                            @Value("${zona15.admin.usuario:admin}") String usuarioAdmin,
                            @Value("${zona15.admin.clave:Admin2026}") String claveAdmin) {
        this.usuarios = usuarios;
        this.codificador = codificador;
        this.usuarioAdmin = usuarioAdmin;
        this.claveAdmin = claveAdmin;
    }

    @Override
    public void run(String... args) {
        if (usuarios.existsByRol(Rol.ADMIN)) {
            return;
        }
        usuarios.save(new Usuario(usuarioAdmin.toLowerCase(), codificador.encode(claveAdmin), Rol.ADMIN, null));
    }
}