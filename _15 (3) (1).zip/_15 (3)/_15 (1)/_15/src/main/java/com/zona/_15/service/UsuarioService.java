package com.zona._15.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.model.Cliente;
import com.zona._15.model.RegistroForm;
import com.zona._15.model.Rol;
import com.zona._15.model.Usuario;
import com.zona._15.repository.ClienteRepository;
import com.zona._15.repository.PedidoRepository;
import com.zona._15.repository.UsuarioRepository;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarios;
    private final ClienteRepository clientes;
    private final PedidoRepository pedidos;
    private final PasswordEncoder codificador;

    public UsuarioService(UsuarioRepository usuarios, ClienteRepository clientes,
                          PedidoRepository pedidos, PasswordEncoder codificador) {
        this.usuarios = usuarios;
        this.clientes = clientes;
        this.pedidos = pedidos;
        this.codificador = codificador;
    }

    public List<Usuario> listar() {
        return usuarios.findAllByOrderByCreadoDesc();
    }

    public Optional<Usuario> buscarPorUsername(String username) {
        return usuarios.findByUsername(username);
    }

    public boolean usernameEnUso(String username) {
        return usuarios.existsByUsername(username.trim().toLowerCase());
    }

    // El teléfono identifica al cliente, así que no puede repetirse.
    public boolean telefonoEnUso(String telefono) {
        return clientes.findByTelefono(telefono.trim()).isPresent();
    }

    // Crea el cliente y su cuenta de usuario juntos.
    @Transactional
    public Usuario registrar(RegistroForm formulario) {
        Cliente cliente = new Cliente();
        cliente.setNombre(formulario.getNombre());
        cliente.setTelefono(formulario.getTelefono());
        cliente.setDireccion(formulario.getDireccion());
        cliente = clientes.save(cliente);

        Usuario usuario = new Usuario(
                formulario.getUsername().toLowerCase(),
                codificador.encode(formulario.getClave()),
                Rol.USUARIO,
                cliente);
        return usuarios.save(usuario);
    }

   
    public Map<Long, Long> pedidosPorUsuario(List<Usuario> lista) {
        Map<Long, Long> conteo = new HashMap<>();
        for (Usuario u : lista) {
            long total = (u.getCliente() == null) ? 0L : pedidos.countByClienteId(u.getCliente().getId());
            conteo.put(u.getId(), total);
        }
        return conteo;
    }
}