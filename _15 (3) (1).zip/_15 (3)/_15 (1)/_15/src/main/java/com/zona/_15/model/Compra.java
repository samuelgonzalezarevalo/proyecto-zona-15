package com.zona._15.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "compras")
public class Compra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "proveedor_id")
    private Proveedor proveedor;

    @NotNull(message = "La fecha es obligatoria.")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(nullable = false)
    private LocalDate fecha = LocalDate.now();

    @NotBlank(message = "El insumo es obligatorio.")
    @Size(min = 2, max = 80, message = "El insumo debe tener entre 2 y 80 caracteres.")
    @Column(nullable = false, length = 80)
    private String insumo;

    @NotNull(message = "La cantidad es obligatoria.")
    @DecimalMin(value = "0.01", message = "La cantidad debe ser mayor que cero.")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal cantidad;

    @NotBlank(message = "La unidad es obligatoria.")
    @Size(max = 20, message = "La unidad puede tener máximo 20 caracteres.")
    @Column(nullable = false, length = 20)
    private String unidad;

    @NotNull(message = "El costo es obligatorio.")
    @Min(value = 1, message = "El costo debe ser mayor que cero.")
    @Column(nullable = false)
    private Integer costoTotal;

    public Compra() {
    }

    public String getCantidadTexto() {
        return cantidad == null ? "" : cantidad.stripTrailingZeros().toPlainString();
    }

    public String getFechaTexto() {
        return fecha == null ? "" : fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Proveedor getProveedor() { return proveedor; }
    public void setProveedor(Proveedor proveedor) { this.proveedor = proveedor; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public String getInsumo() { return insumo; }
    public void setInsumo(String insumo) {
        this.insumo = (insumo == null) ? null : insumo.trim().toUpperCase();
    }

    public BigDecimal getCantidad() { return cantidad; }
    public void setCantidad(BigDecimal cantidad) { this.cantidad = cantidad; }

    public String getUnidad() { return unidad; }
    public void setUnidad(String unidad) { this.unidad = unidad; }

    public Integer getCostoTotal() { return costoTotal; }
    public void setCostoTotal(Integer costoTotal) { this.costoTotal = costoTotal; }
}