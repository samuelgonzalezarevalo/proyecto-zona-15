package com.zona._15.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.zona._15.model.Zona;
import com.zona._15.repository.ZonaRepository;

@Service
public class ZonaService {

    private final ZonaRepository repositorio;

    public ZonaService(ZonaRepository repositorio) {
        this.repositorio = repositorio;
    }

    public List<Zona> listar() {
        return repositorio.findAllByOrderByNombreAsc();
    }

    public Optional<Zona> buscar(Long id) {
        return repositorio.findById(id);
    }

    public boolean nombreEnUso(String nombre) {
        return repositorio.existsByNombreIgnoreCase(nombre.trim());
    }

    public Zona guardar(Zona zona) {
        return repositorio.save(zona);
    }

    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }
}