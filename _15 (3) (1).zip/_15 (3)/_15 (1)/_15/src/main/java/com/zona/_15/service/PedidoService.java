package com.zona._15.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zona._15.model.EstadoPedido;
import com.zona._15.model.Pedido;
import com.zona._15.model.Producto;
import com.zona._15.model.TipoPedido;
import com.zona._15.model.Zona;
import com.zona._15.repository.ClienteRepository;
import com.zona._15.repository.FacturaRepository;
import com.zona._15.repository.PedidoRepository;
import com.zona._15.repository.ProductoRepository;

@Service
public class PedidoService {

    private final PedidoRepository pedidos;
    private final ProductoRepository productos;
    private final ClienteRepository clientes;
    private final FacturaRepository facturas;
    private final MesaService mesas;
    private final ZonaService zonas;

    public PedidoService(PedidoRepository pedidos, ProductoRepository productos,
                         ClienteRepository clientes, FacturaRepository facturas,
                         MesaService mesas, ZonaService zonas) {
        this.pedidos = pedidos;
        this.productos = productos;
        this.clientes = clientes;
        this.facturas = facturas;
        this.mesas = mesas;
        this.zonas = zonas;
    }

    public List<Pedido> listar() {
        return pedidos.findAllByOrderByFechaDesc();
    }

    public Optional<Pedido> buscar(Long id) {
        return pedidos.findConDetallesById(id);
    }

    
    public List<Pedido> listarParaCocina() {
        return pedidos.findByEstadoInOrderByFechaAsc(
                        List.of(EstadoPedido.RECIBIDO, EstadoPedido.EN_PREPARACION))
                .stream()
                .filter(p -> !p.getDetalles().isEmpty())
                .toList();
    }

   
    @Transactional
    public Pedido crear(Long clienteId, TipoPedido tipo, Long mesaId, Long zonaId) {
        Pedido pedido = new Pedido();
        pedido.setTipo(tipo);
        if (clienteId != null) {
            pedido.setCliente(clientes.findById(clienteId).orElse(null));
        }
        if (tipo == TipoPedido.DOMICILIO) {
            Zona zona = (zonaId == null) ? null : zonas.buscar(zonaId).orElse(null);
            if (zona == null) {
                throw new IllegalArgumentException(
                        "Elige el barrio de entrega. Solo hacemos domicilios en Turbaco.");
            }
            pedido.setZonaEntrega(zona.getNombre());
        }
        pedido = pedidos.save(pedido);
        if (tipo == TipoPedido.LOCAL && mesaId != null) {
            mesas.asignar(pedido.getId(), mesaId);
        }
        return pedido;
    }

    @Transactional
    public void agregarProducto(Long pedidoId, Long productoId, int cantidad) {
        Pedido pedido = obtener(pedidoId);
        verificarModificable(pedido);
        Producto producto = productos.findById(productoId)
                .orElseThrow(() -> new IllegalArgumentException("El producto no existe."));
        pedido.agregarProducto(producto, cantidad);
    }

    @Transactional
    public void quitarDetalle(Long pedidoId, Long detalleId) {
        Pedido pedido = obtener(pedidoId);
        verificarModificable(pedido);
        pedido.quitarDetalle(detalleId);
    }

    
    @Transactional
    public void avanzar(Long pedidoId) {
        Pedido pedido = obtener(pedidoId);
        EstadoPedido siguiente = pedido.getEstado().siguiente();
        if (siguiente == null) {
            throw new IllegalArgumentException("Este pedido ya no puede cambiar de estado.");
        }
        if (siguiente == EstadoPedido.EN_PREPARACION && pedido.getDetalles().isEmpty()) {
            throw new IllegalArgumentException("Agrega productos antes de enviarlo a preparación.");
        }
        pedido.setEstado(siguiente);
    }

    
    @Transactional
    public void cancelar(Long pedidoId) {
        Pedido pedido = obtener(pedidoId);
        if (!pedido.getEstado().isCancelable()) {
            throw new IllegalArgumentException("Solo se puede cancelar un pedido que aún no está en preparación.");
        }
        if (facturas.existsByPedidoId(pedidoId)) {
            throw new IllegalArgumentException("El pedido ya fue cobrado y no se puede cancelar.");
        }
        pedido.setEstado(EstadoPedido.CANCELADO);
        pedido.setMesaEnUso(false);
    }

    private Pedido obtener(Long pedidoId) {
        return pedidos.findById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("El pedido no existe."));
    }

    // Un pedido cobrado, o que ya salió del estado "Recibido", no se puede modificar.
    private void verificarModificable(Pedido pedido) {
        if (facturas.existsByPedidoId(pedido.getId())) {
            throw new IllegalArgumentException("El pedido ya fue cobrado y no se puede modificar.");
        }
        if (!pedido.getEstado().isModificable()) {
            throw new IllegalArgumentException("Solo se puede modificar un pedido en estado Recibido.");
        }
    }
}