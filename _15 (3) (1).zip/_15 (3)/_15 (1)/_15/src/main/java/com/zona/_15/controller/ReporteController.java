package com.zona._15.controller;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.zona._15.service.ReporteService;

@Controller
public class ReporteController {

    private final ReporteService servicio;

    public ReporteController(ReporteService servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/reportes")
    public String reportes(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            Model modelo) {
        LocalDate hoy = LocalDate.now();
        if (desde == null) {
            desde = hoy;
        }
        if (hasta == null) {
            hasta = hoy;
        }
        if (hasta.isBefore(desde)) {
            LocalDate cambio = desde;
            desde = hasta;
            hasta = cambio;
        }
        modelo.addAttribute("reporte", servicio.generar(desde, hasta));
        modelo.addAttribute("desde", desde.toString());
        modelo.addAttribute("hasta", hasta.toString());
        return "reportes";
    }
}