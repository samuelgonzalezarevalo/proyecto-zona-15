package com.zona._15.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.zona._15.service.PanelService;

@Controller
public class InicioController {

    private final PanelService panel;

    public InicioController(PanelService panel) {
        this.panel = panel;
    }

    @GetMapping("/")
    public String inicio(Model modelo) {
        modelo.addAttribute("panel", panel.generar());
        return "index";
    }
}