package com.zona._15.controller;

import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zona._15.config.DatosNegocio;
import com.zona._15.model.Factura;
import com.zona._15.model.MetodoPago;
import com.zona._15.service.CodigoQr;
import com.zona._15.service.FacturaService;

@Controller
public class FacturaController {

    private final FacturaService servicio;
    private final DatosNegocio negocio;

    public FacturaController(FacturaService servicio, DatosNegocio negocio) {
        this.servicio = servicio;
        this.negocio = negocio;
    }

    @GetMapping("/facturas")
    public String listar(Model modelo) {
        modelo.addAttribute("facturas", servicio.listar());
        return "facturas/lista";
    }

    @GetMapping("/facturas/{id}")
    public String ver(@PathVariable Long id, Model modelo, RedirectAttributes aviso) {
        Optional<Factura> factura = servicio.buscar(id);
        if (factura.isEmpty()) {
            aviso.addFlashAttribute("error", "La factura no existe.");
            return "redirect:/facturas";
        }
        modelo.addAttribute("factura", factura.get());
        modelo.addAttribute("negocio", negocio);
        modelo.addAttribute("qr", CodigoQr.svg(textoDelQr(factura.get())));
        return "facturas/ver";
    }

    @PostMapping("/pedidos/{id}/cobrar")
    public String cobrar(@PathVariable Long id, @RequestParam MetodoPago metodoPago,
                         @RequestParam(required = false) String identificacion,
                         RedirectAttributes aviso) {
        try {
            Factura factura = servicio.facturar(id, metodoPago, identificacion);
            return "redirect:/facturas/" + factura.getId();
        } catch (IllegalArgumentException e) {
            aviso.addFlashAttribute("error", e.getMessage());
            return "redirect:/pedidos/" + id;
        }
    }

    private String textoDelQr(Factura factura) {
        return "Factura " + factura.getNumero()
                + " | NIT " + negocio.getNit()
                + " | Fecha " + factura.getFechaTexto()
                + " | Total $" + factura.getTotal()
                + " | CUFE " + (factura.getCufe() == null ? "N/D" : factura.getCufe());
    }
}